#include <stdio.h>
#include <conio.h>

void bubble(int vetor[], int qtd)
{
	int i, j, aux, k=qtd-1;

	for(i=0; i<qtd; i++)
	{
		for(j=0; j<k; j++)
		{
			if(vetor[j] > vetor[j+1])
			{
				aux = vetor[j];
				vetor[j] = vetor[j+1];
				vetor[j+1] = aux;
			}
		}
		k--;
	}
}

int main()
{
	int vetor[] = {20, 1, 19, 2, 18, 3, 17, 4, 16, 5, 15, 6, 14, 7, 13, 8, 12, 9, 11, 10};
    int vetoraux[] = {20, 1, 19, 2, 18, 3, 17, 4, 16, 5, 15, 6, 14, 7, 13, 8, 12, 9, 11, 10};
	int i;

	bubble(vetor, 20);

	printf("Sequencia Desordenada: \n\n");
	for(i=0; i<20; i++)
	{
		printf("     %d ", vetoraux[i]);
	}

	printf("\n\n");

	printf("Sequencia Ordenada: \n\n");
	for(i=0; i<20; i++)
	{
		printf("     %d ", vetor[i]);
	}

	printf("\n\n");

	printf("Vetor com numeros pares: \n\n");
    for(i=0; i<20; i++)
    {
        if(vetor[i]%2==0)
            printf("    %d", vetor[i]);
    }

    printf("\n\n");

	printf("Vetor com numeros impares: \n\n");
	for(i=0; i<20; i++)
    {
        if(vetor[i]%2!=0)
            printf("     %d", vetor[i]);
    }

	printf("\n\n");

	getch();
}
