#include <stdio.h>
#include <conio.h>

void selection(int vetor[], int maximo)
{
    int i, j, aux, minimo
}

main()
{

    getch();
}
